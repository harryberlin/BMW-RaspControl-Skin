#!/usr/bin/env python

#Name: BMWRaspControl SkinUpdater
#Version: v0.6
#Owner: harryberlin

import urllib,os,re,urllib2
import xbmc,xbmcgui
import zipfile, shutil, time

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()

bDebug = False

sUrl ='https://github.com/harryberlin/BMW-RaspControl-Skin/raw/master/skin.confluence-vertical-beta.zip'
sTargetFilePath = '/tmp/download.zip'

sAddonName = 'skin.confluence-vertical-beta'
sAddonSrcPath = '/home/osmc/.kodi/addons/' + sAddonName + '/'

sBackupDateTime = time.strftime("%Y%m%d") + '_' + time.strftime("%H-%M-%S")
sBackupPath = '/home/osmc/backup/' + sBackupDateTime + '_' + sAddonName + '/'

if bDebug: xbmcgui.Dialog().ok('Updater', sBackupDateTime, '')	

def DownloaderClass(url,dest):
    global dp
    dp.create('BMWRaspControl Updater', 'BMW RaspControl Skin - Update', '')
    dp.update(0, 'BMW RaspControl Skin - Update',  'waiting for File Connection...')
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
		percent = min((numblocks*blocksize*90)/filesize, 100)
		print percent
		dp.update(percent, 'BMW RaspControl Skin - Update', 'Downloading File...')
	except:
		percent = 90
		dp.update(percent, 'BMW RaspControl Skin - Update', 'installiere Skin...')
	if dp.iscanceled(): 
		print "Download Abgebrochen"		
		quit()
	
def checkinternet():
    try:
        response=urllib2.urlopen('http://173.194.32.223',timeout=2)
        return True
    except urllib2.URLError as err: pass
    return False


#################################################################################################################

if dialog.yesno("BMW RaspControl Updater","Skin Confluence-Vertical", "Are you sure to update the Skin?") != 1: 
	quit()

xbmc.sleep(300)

if checkinternet() != 1: 
	xbmc.executebuiltin("Notification(BMWRaspControl Skin Updater,VERBINDUNGSFEHLER!, 500)")
	quit()

#Downloading File		
DownloaderClass(sUrl, sTargetFilePath)

xbmc.sleep(1000)

#check for existing file
if not os.path.isfile(sTargetFilePath):
	if bDebug: xbmcgui.Dialog().ok('Updater', 'File does not exist', '')
	xbmc.executebuiltin("Notification(BMWRaspControl Skin Updater,Downloaded File is missing!, 500)")
	dp.close()
	quit()

#Installing file
if bDebug: xbmcgui.Dialog().ok('Updater', 'File exist', '')
dp.update(int(91), 'BMW RaspControl Skin - Update', 'unzipping File...')

if bDebug: xbmcgui.Dialog().ok('Updater', 'File unzip', '')

#check zip file
try:
	if bDebug: xbmcgui.Dialog().ok('Updater', 'Zipfile is good', '')
	zip_ref = zipfile.ZipFile(sTargetFilePath, 'r')
except:
	xbmcgui.Dialog().ok('Updater', 'Zipfile is bad', '')
	dp.close()	
	quit()

#unzip file
zip_ref.extractall('/tmp')
zip_ref.close()
	
dp.update(int(95), 'BMW RaspControl Skin - Update', 'Backup current Skin...')

xbmc.sleep(500)
		
#change path owner		
f=os.popen('sudo chown osmc:osmc ' + xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8') + '/')
print f

#move directory for backup
shutil.move(sAddonSrcPath, sBackupPath)
if bDebug: xbmcgui.Dialog().ok('Updater', 'old files backuped', '')
	
dp.update(int(98), 'BMW RaspControl Skin - Update', 'Installing new Skinfiles...')

xbmc.sleep(500)

#move new files
shutil.move('/tmp/' + sAddonName, sAddonSrcPath)
if bDebug: xbmcgui.Dialog().ok('Updater', 'new files placed', '')

dp.update(int(99), 'BMW RaspControl Skin - Update', 'Installing Skin Done.')

dp.update(int(100), 'BMW RaspControl Skin - Update', 'Remove Tempfile.')

xbmc.sleep(500)

#remove downloaded temp file
os.remove(sTargetFilePath)

xbmc.sleep(1000)
xbmc.executebuiltin("ReloadSkin()")
xbmc.executebuiltin("Notification(BMWRaspControl Skin Updater,Update erfolgreich!, 500)")
	
dp.close()	
pass
