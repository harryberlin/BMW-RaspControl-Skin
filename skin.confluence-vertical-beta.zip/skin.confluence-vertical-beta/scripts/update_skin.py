#!/usr/bin/env python

#Name: BMWRaspControl SkinUpdater
#Version: v0.4
#Owner: Horst12345

import urllib,os,re,urllib2
import xbmc,xbmcgui
 
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("BMWRaspControl Updater","Lade Datei", "BMW RaspControl Skin - Update")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "Download Abgebrochen"
        dp.close()		
	quit()
	
def checkinternet():
    try:
        response=urllib2.urlopen('http://173.194.32.223',timeout=2)
        return True
    except urllib2.URLError as err: pass
    return False

dialog = xbmcgui.Dialog()
if dialog.yesno("BMW RaspControl Updater","Skin Confluence-Vertical", "Are you sure to update the Skin?") == 1:
    if checkinternet() == 1:
		url ='https://github.com/harryberlin/BMW-RaspControl-Skin/archive/master.zip'
		DownloaderClass(url,"/tmp/master.zip")
		xbmc.sleep(1000)
		if os.path.isfile("/tmp/master.zip"):
			os.system('sh /home/osmc/.kodi/addons/skin.confluence-vertical/scripts/update_skin.sh')
			xbmc.sleep(1000)
			xbmc.executebuiltin("ReloadSkin()")
			xbmc.executebuiltin("Notification(BMWRaspControl Skin Updater,Update erfolgreich!,500)")
		else:
			xbmc.executebuiltin("Notification(BMWRaspControl Skin Updater,Downloaded File is missing!,500)")
			quit()
    else:
		xbmc.executebuiltin("Notification(BMWRaspControl Skin Updater,VERBINDUNGSFEHLER!,500)")
pass
