#Name: BMWRaspControl SkinUpdater
#Version: v0.5
#Owner: Horst12345
#Edited by harryberlin

cd /tmp
sudo unzip -o master.zip
sudo mv /home/osmc/.kodi/addons/skin.confluence-vertical /home/osmc/backup
sudo mv BMW-RaspControl-Skin-master/skin.confluence-vertical /home/osmc/.kodi/addons/
sudo rm master.zip
sudo rm -Rf BMW-RaspControl-Skin-master
