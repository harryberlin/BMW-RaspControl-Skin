#Name: BMWRaspControl SkinUpdater
#Version: v0.5
#Owner: Horst12345
#Edited by harryberlin

cd /tmp
sudo unzip -o skinbeta.zip
sudo mv /home/osmc/.kodi/addons/skin.confluence-vertical-beta /home/osmc/backup
sudo mv skinbeta/skin.confluence-vertical-beta /home/osmc/.kodi/addons/
sudo rm skinbeta.zip
sudo rm -Rf skinbeta
