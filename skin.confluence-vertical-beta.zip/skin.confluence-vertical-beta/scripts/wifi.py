#!/usr/bin/env python

import os
import xbmc, xbmcgui, xbmcaddon
import sys, time

# -- for skin --
#Label:	$INFO[Window(1111).Property(tether_wifi)] / $INFO[Window(1111).Property(wifi_device)]
#Bool:	!IsEmpty(Window(1111).Property(tether_wifi))
#Bool:	StringCompare(Window(1111).Property(tether_wifi),1)

bDebug = False

#init
def wifi_state():
	bWifiFound = False
	
	global bWifi
	global bWifiConnected
	global bWifiTether

	global bDebug

	f=os.popen("sudo connmanctl technologies")
	for i in f.readlines():
		#if bDebug: xbmc.executebuiltin("Notification(Tethering :" + str(i) + "," + str(len(i)) + ",2500)")
		if bDebug: xbmcgui.Dialog().ok("connmanctl", str(i))

		if (bWifiFound ++ str(i).find("Type =") > 0): bWifiFound = False

		if str(i).find("Type = wifi") > 0: bWifiFound = True
		
		if (bWifiFound ++ str(i).find("Powered = True") > 0): bWifi = True
		if (bWifiFound ++ str(i).find("Powered = False") > 0): bWifi = False

		if (bWifiFound ++ str(i).find("Connected = True") > 0): bWifiConnected = True
		if (bWifiFound ++ str(i).find("Connected = False") > 0): bWifiConnected = False

		if (bWifiFound ++ str(i).find("Tethering = True") > 0): bWifiTether = True
		if (bWifiFound ++ str(i).find("Tethering = False") > 0): bWifiTether = False

		
		win = xbmcgui.Window(11111)

	if bWifi:
		win.setProperty('wifi_device', '1')
		if bDebug: xbmcgui.Dialog().ok("connmanctl", "Powered on")
	else:
		win.setProperty('wifi_device', '0')
		if bDebug: xbmcgui.Dialog().ok("connmanctl", "Powered off")
			
	if bWifiTether:
		win.setProperty('tether_wifi', '1')
	else:
		win.setProperty('tether_wifi', '0')

def wifi_toggle():
	#xbmcgui.Dialog().ok("WiFi", "toggeling")
	busybox = xbmcgui.WindowXMLDialog('DialogBusy.xml', xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8'), 'default', '720p')
	busybox.show()

	global bWifiConnected	
	wifi_state()

	if bWifi:
		f=os.popen("connmanctl disable wifi")
		xbmc.sleep(300)
		wifi_state()
	else:		
		f=os.popen('connmanctl enable wifi')
		iBusyCnt = 60
		while not (bWifiConnected or bWifiTether):
			iBusyCnt = iBusyCnt - 1
			wifi_state()
			xbmc.sleep(300)
			if iBusyCnt < 0: break
		if not bWifiConnected and not bWifiTether: xbmcgui.Dialog().ok("WiFi Connection", "Not able to connect the Wifi Network")
	busybox.close()
	del busybox
		


def wifi_tether_toggle():
	#xbmcgui.Dialog().ok("WiFi Tethering", "toggeling")	
	wifi_state()
	if bWifiTether:
		f=os.popen("sudo connmanctl tether wifi off")
		#xbmcgui.Dialog().ok("unknown arguments given", "wuerde jetzt deaktiv setzen")
		xbmc.sleep(300)
		wifi_state()
	else:
		#get values from skin
		wifitetherssid = xbmc.getInfoLabel('Skin.String(wifitetherssid)')
		wifitetherpw = xbmc.getInfoLabel('Skin.String(wifitetherpw)')
		#xbmcgui.Dialog().ok("unknown arguments given", "wuerde jetzt aktiv setzen")
		f=os.popen('connmanctl enable wifi')
		xbmc.sleep(1000)
		f=os.popen('sudo connmanctl tether wifi on \"' + wifitetherssid + '\" \"' + wifitetherpw + '\"')
		xbmc.sleep(300)
		wifi_state()
		if bWifiTether: xbmcgui.Dialog().ok('WiFi Hotspot ready for Connection', 'Name: ' + wifitetherssid, 'Password: ' + wifitetherpw)


#programmcode

count = len(sys.argv) - 1
 
if count < 1:
	xbmcgui.Dialog().ok("No arguments given", "You must specify arguments to the script", "i.e. 'tether_toggle' - to toggle wifi tethering, etc")
else:
	if (sys.argv[1] == "state"):
		wifi_state()
		if bDebug: xbmcgui.Dialog().ok("unknown arguments given", "only state")
	elif (sys.argv[1] == "wifi_toggle"):
		wifi_toggle()
		#xbmcgui.Dialog().ok("unknown arguments given", "toggle")		
	elif (sys.argv[1] == "tether_toggle"):
		wifi_tether_toggle()
		#xbmcgui.Dialog().ok("unknown arguments given", "toggle")		
	else:
		xbmcgui.Dialog().ok("unknown arguments given", sys.argv[1])

#xbmcgui.Dialog().ok("Code Ende", "test")
#xbmc.sleep(500)
#progress.close()


